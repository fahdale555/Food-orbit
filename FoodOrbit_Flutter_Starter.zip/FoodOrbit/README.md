# FoodOrbit — Flutter customer app starter

This is a **demo starter project**, not a production delivery platform.

## Included
- FoodOrbit branding and Peshawar-first home screen
- Sample restaurant/food listings
- Category strip
- Add-to-cart and cart total
- Checkout form with Cash on Delivery demo
- English / Urdu text toggle

## Run
1. Install Flutter SDK and Android Studio (or Xcode on macOS for iOS).
2. Extract this ZIP.
3. In the project folder run:
   flutter pub get
   flutter run

## Build
- Android APK: `flutter build apk --release`
- iOS: `flutter build ios --release` (requires macOS and Xcode)

## Important demo limitations
- OTP login is not connected yet.
- Menu and prices are sample data.
- Checkout only shows a demo confirmation; it does not send a real order.
- No restaurant dashboard, rider app, live tracking, payment gateway, or admin backend.
- Before launch, connect a secure backend (e.g. Supabase), SMS OTP provider, maps, notifications,
  restaurant onboarding, delivery zones, and server-side price/order validation.
- Keep ownership of the app-store accounts, source repository, domain, and backend under your control.

Brand concept: FoodOrbit — “Good food. In your orbit.”
Palette: Orbit Orange #FF7043, Midnight Navy #101C32, Cloud White #F4F5F7.
