import 'package:flutter/material.dart';

void main() => runApp(const FoodOrbitApp());

const orange = Color(0xFFFF7043);
const navy = Color(0xFF101C32);
const cream = Color(0xFFF4F5F7);

class FoodOrbitApp extends StatefulWidget {
  const FoodOrbitApp({super.key});
  @override
  State<FoodOrbitApp> createState() => _FoodOrbitAppState();
}

class _FoodOrbitAppState extends State<FoodOrbitApp> {
  bool urdu = false;
  final List<FoodItem> cart = [];

  String t(String en, String ur) => urdu ? ur : en;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'FoodOrbit',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: cream,
        colorScheme: ColorScheme.fromSeed(seedColor: orange),
        appBarTheme: const AppBarTheme(
          backgroundColor: navy, foregroundColor: Colors.white,
          centerTitle: false, elevation: 0,
        ),
      ),
      home: HomePage(
        urdu: urdu,
        onLanguage: () => setState(() => urdu = !urdu),
        cart: cart,
        onAdd: (item) => setState(() => cart.add(item)),
        onRemove: (index) => setState(() => cart.removeAt(index)),
        tr: t,
      ),
    );
  }
}

class FoodItem {
  final String name, restaurant, emoji;
  final int price;
  const FoodItem(this.name, this.restaurant, this.emoji, this.price);
}

const foods = [
  FoodItem('Chicken Karahi', 'Khyber Shinwari', '🍲', 1250),
  FoodItem('Zinger Burger', 'Burger Hub', '🍔', 650),
  FoodItem('Chicken Biryani', 'Peshawar Foods', '🍛', 420),
  FoodItem('Chapli Kebab', 'Namkeen Tikka House', '🥘', 550),
  FoodItem('Loaded Fries', 'Burger Hub', '🍟', 390),
  FoodItem('Pizza (Small)', 'Peshawar Foods', '🍕', 950),
];

class HomePage extends StatelessWidget {
  final bool urdu;
  final VoidCallback onLanguage;
  final List<FoodItem> cart;
  final ValueChanged<FoodItem> onAdd;
  final ValueChanged<int> onRemove;
  final String Function(String, String) tr;

  const HomePage({super.key, required this.urdu, required this.onLanguage,
    required this.cart, required this.onAdd, required this.onRemove,
    required this.tr});

  @override
  Widget build(BuildContext context) {
    final total = cart.fold<int>(0, (s, item) => s + item.price);
    return Scaffold(
      appBar: AppBar(
        title: const Row(children: [
          Icon(Icons.public, color: orange, size: 27),
          SizedBox(width: 8),
          Text('FoodOrbit', style: TextStyle(fontWeight: FontWeight.w800)),
        ]),
        actions: [
          TextButton(onPressed: onLanguage,
            child: Text(urdu ? 'English' : 'اردو',
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
          IconButton(
            onPressed: () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => CartPage(cart: cart, total: total, tr: tr))),
            icon: Badge(label: Text('${cart.length}'),
              child: const Icon(Icons.shopping_bag_outlined)),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              gradient: const LinearGradient(colors: [navy, Color(0xFF263B5B)]),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(tr('GOOD FOOD. IN YOUR ORBIT.', 'مزیدار کھانا، آپ کے قریب'),
                style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              Text(tr('Discover • Order • Enjoy', 'تلاش کریں • آرڈر کریں • لطف اٹھائیں'),
                style: const TextStyle(color: Colors.white70)),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 12),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)),
                child: Row(children: [
                  const Icon(Icons.location_on, color: orange),
                  const SizedBox(width: 8),
                  Expanded(child: Text(tr('Delivering in Peshawar', 'پشاور میں ڈیلیوری'),
                    style: const TextStyle(color: navy, fontWeight: FontWeight.w600))),
                  const Icon(Icons.keyboard_arrow_down, color: navy),
                ]),
              )
            ]),
          ),
          const SizedBox(height: 22),
          Text(tr('Explore categories', 'کیٹیگریز'),
            style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800, color: navy)),
          const SizedBox(height: 12),
          SizedBox(height: 94, child: ListView(
            scrollDirection: Axis.horizontal,
            children: const [
              CategoryTile('🍔', 'Burgers'), CategoryTile('🍕', 'Pizza'),
              CategoryTile('🍗', 'Chicken'), CategoryTile('🍛', 'Rice'),
              CategoryTile('🥤', 'Drinks'),
            ],
          )),
          const SizedBox(height: 20),
          Row(children: [
            Expanded(child: Text(tr('Popular near you', 'آپ کے قریب مقبول'),
              style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800, color: navy))),
            Text(tr('Peshawar', 'پشاور'), style: const TextStyle(color: orange, fontWeight: FontWeight.bold)),
          ]),
          const SizedBox(height: 10),
          ...foods.map((food) => FoodCard(food: food, onAdd: () {
            onAdd(food);
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('${food.name} ${tr('added to cart', 'کارٹ میں شامل ہوگیا')}'),
                duration: const Duration(milliseconds: 900)));
          })),
          const SizedBox(height: 12),
          const Center(child: Text('FoodOrbit • Peshawar first',
            style: TextStyle(color: Colors.black45, fontSize: 12))),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: 0, selectedItemColor: orange, unselectedItemColor: Colors.grey,
        items: [
          BottomNavigationBarItem(icon: const Icon(Icons.home_outlined), label: tr('Home', 'ہوم')),
          BottomNavigationBarItem(icon: const Icon(Icons.receipt_long), label: tr('Orders', 'آرڈرز')),
          BottomNavigationBarItem(icon: const Icon(Icons.person_outline), label: tr('Profile', 'پروفائل')),
        ],
      ),
    );
  }
}

class CategoryTile extends StatelessWidget {
  final String emoji, label;
  const CategoryTile(this.emoji, this.label, {super.key});
  @override
  Widget build(BuildContext context) => Container(
    width: 82, margin: const EdgeInsets.only(right: 10),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Text(emoji, style: const TextStyle(fontSize: 28)),
      const SizedBox(height: 6),
      Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
    ]),
  );
}

class FoodCard extends StatelessWidget {
  final FoodItem food;
  final VoidCallback onAdd;
  const FoodCard({super.key, required this.food, required this.onAdd});
  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 11),
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(17)),
    child: Row(children: [
      Container(width: 68, height: 68,
        decoration: BoxDecoration(color: const Color(0xFFFFF0EA), borderRadius: BorderRadius.circular(14)),
        child: Center(child: Text(food.emoji, style: const TextStyle(fontSize: 36)))),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(food.name, style: const TextStyle(fontWeight: FontWeight.w800, color: navy, fontSize: 15)),
        const SizedBox(height: 4),
        Text(food.restaurant, style: const TextStyle(color: Colors.black54, fontSize: 12)),
        const SizedBox(height: 6),
        Text('Rs. ${food.price}', style: const TextStyle(fontWeight: FontWeight.w800, color: orange)),
      ])),
      FilledButton(
        style: FilledButton.styleFrom(backgroundColor: orange, foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 13)),
        onPressed: onAdd, child: const Text('Add +'),
      ),
    ]),
  );
}

class CartPage extends StatelessWidget {
  final List<FoodItem> cart;
  final int total;
  final String Function(String, String) tr;
  const CartPage({super.key, required this.cart, required this.total, required this.tr});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(tr('Your cart', 'آپ کا کارٹ'))),
    body: cart.isEmpty
      ? Center(child: Text(tr('Your cart is empty', 'آپ کا کارٹ خالی ہے')))
      : ListView(padding: const EdgeInsets.all(16), children: [
          ...cart.map((f) => ListTile(
            leading: Text(f.emoji, style: const TextStyle(fontSize: 28)),
            title: Text(f.name), subtitle: Text(f.restaurant),
            trailing: Text('Rs. ${f.price}', style: const TextStyle(fontWeight: FontWeight.bold)),
          )),
          const Divider(),
          ListTile(title: Text(tr('Subtotal', 'کل رقم')),
            trailing: Text('Rs. $total', style: const TextStyle(fontWeight: FontWeight.w800))),
          const SizedBox(height: 16),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: orange, padding: const EdgeInsets.all(15)),
            onPressed: () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => CheckoutPage(total: total, tr: tr))),
            child: Text(tr('Proceed to checkout', 'چیک آؤٹ کریں')),
          ),
        ]),
  );
}

class CheckoutPage extends StatefulWidget {
  final int total;
  final String Function(String, String) tr;
  const CheckoutPage({super.key, required this.total, required this.tr});
  @override
  State<CheckoutPage> createState() => _CheckoutPageState();
}
class _CheckoutPageState extends State<CheckoutPage> {
  final name = TextEditingController();
  final phone = TextEditingController();
  final address = TextEditingController();
  @override
  void dispose() { name.dispose(); phone.dispose(); address.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.tr('Checkout', 'چیک آؤٹ'))),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      Text(widget.tr('Delivery details', 'ڈیلیوری کی تفصیلات'),
        style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: navy)),
      const SizedBox(height: 14),
      TextField(controller: name, decoration: InputDecoration(labelText: widget.tr('Full name', 'پورا نام'), border: const OutlineInputBorder())),
      const SizedBox(height: 12),
      TextField(controller: phone, keyboardType: TextInputType.phone,
        decoration: InputDecoration(labelText: widget.tr('Mobile number', 'موبائل نمبر'), border: const OutlineInputBorder())),
      const SizedBox(height: 12),
      TextField(controller: address, maxLines: 3,
        decoration: InputDecoration(labelText: widget.tr('Delivery address in Peshawar', 'پشاور میں ڈیلیوری ایڈریس'), border: const OutlineInputBorder())),
      const SizedBox(height: 18),
      ListTile(
        leading: const Icon(Icons.payments_outlined, color: orange),
        title: Text(widget.tr('Cash on delivery', 'کیش آن ڈیلیوری')),
        subtitle: Text(widget.tr('Demo payment method', 'ڈیمو ادائیگی کا طریقہ')),
      ),
      Text('Total: Rs. ${widget.total}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
      const SizedBox(height: 16),
      FilledButton(
        style: FilledButton.styleFrom(backgroundColor: orange, padding: const EdgeInsets.all(16)),
        onPressed: () {
          if (name.text.trim().isEmpty || phone.text.trim().isEmpty || address.text.trim().isEmpty) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(widget.tr('Please complete all fields', 'تمام معلومات درج کریں'))));
            return;
          }
          showDialog(context: context, builder: (_) => AlertDialog(
            title: Text(widget.tr('Demo order placed!', 'ڈیمو آرڈر ہوگیا!')),
            content: Text(widget.tr('FoodOrbit order flow is working in demo mode. No real order was sent.',
              'فوڈ آربٹ ڈیمو موڈ میں کام کر رہا ہے۔ اصل آرڈر نہیں بھیجا گیا۔')),
            actions: [TextButton(onPressed: () {
              Navigator.pop(context); Navigator.popUntil(context, (r) => r.isFirst);
            }, child: const Text('OK')],
          ));
        },
        child: Text(widget.tr('Place demo order', 'ڈیمو آرڈر دیں')),
      ),
    ]),
  );
}
